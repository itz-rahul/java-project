package Registration;
import javax.naming.Name;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
public class Signup extends JFrame implements ActionListener, FocusListener,differentfuncationchacker{           //Concepts
                                                                                        // polymorphism
    ImageIcon signpage = new ImageIcon("signuppage picture.jpg");                 //single inheritance
    JLabel label = new JLabel();                                                        // multiple interfance
    JTextField firstname = new JTextField("First name");                               // file handling
    JTextField lastname = new JTextField("Last name(optional)");                      // Excaption handling
    public JTextField username = new JTextField("email");
    JTextField password = new JTextField("password");
    JTextField confirmpassword = new JTextField("confirm password");
    JButton next = new JButton();
    JButton BACK=new JButton();
   public Signup() {
    }
    Signup(int x) {
        buttonproperties(next,300,600,120,50,"Next");
        buttonproperties(BACK,40,600,120,50,"Back");
        textfieldproperties();
        labelproperties();
        pageproperties();
    }
    private void buttonproperties(JButton button,int x,int y,int w,int h,String Name) {
        button.addActionListener(this);
        button.setBackground(Color.BLUE);
        button.setText(Name);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 20));
        button.setBounds(x, y, w, h);
        button.setFocusPainted(false);
        this.add(button);
    }

    private void textfieldproperties() {
        firstname.setFont(new Font("Arial", Font.ITALIC, 15));
        lastname.setFont(new Font("Arial", Font.ITALIC, 15));
        username.setFont(new Font("Arial", Font.ITALIC, 15));
        password.setFont(new Font("Arial", Font.ITALIC, 15));
        confirmpassword.setFont(new Font("Arial", Font.ITALIC, 15));
        firstname.setBorder(BorderFactory.createLineBorder(Color.black, 1));
        lastname.setBorder(BorderFactory.createLineBorder(Color.black, 1));
        username.setBorder(BorderFactory.createLineBorder(Color.black, 1));
        password.setBorder(BorderFactory.createLineBorder(Color.black, 1));
        confirmpassword.setBorder(BorderFactory.createLineBorder(Color.black, 1));
        firstname.setBounds(50, 270, 180, 40);
        lastname.setBounds(250, 270, 180, 40);
        username.setBounds(50, 330, 380, 40);
        password.setBounds(50, 400, 180, 40);
        confirmpassword.setBounds(250, 400, 180, 40);
        firstname.addFocusListener(this);
        lastname.addFocusListener(this);
        username.addFocusListener(this);
        password.addFocusListener(this);
        firstname.setForeground(Color.lightGray);
        lastname.setForeground(Color.lightGray);
        username.setForeground(Color.lightGray);
        password.setForeground(Color.lightGray);
        confirmpassword.setForeground(Color.lightGray);
        confirmpassword.addFocusListener(this);
        this.add(firstname);
        this.add(lastname);
        this.add(username);
        this.add(password);
        this.add(confirmpassword);
    }
    private void labelproperties() {
        label.setText("\t\tCreate your Google Classroom Clone Account");
        label.setHorizontalTextPosition(JLabel.LEFT);
        label.setVerticalTextPosition(JLabel.TOP);
        label.setForeground(Color.black);
        label.setIcon(signpage);
        label.setVerticalAlignment(JLabel.CENTER);
        label.setHorizontalAlignment(JLabel.RIGHT);
        label.setFont(new Font("Calibri dark", Font.PLAIN, 22));
        this.add(label);
    }

    private void pageproperties() {
        ImageIcon icon = new ImageIcon("icon.jpg");
        this.setTitle("Registration");
        this.setSize(700, 700);
        this.getContentPane().setBackground(Color.WHITE);
        this.setIconImage(icon.getImage());
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        int  count1 = 0, count2 = 0, count3 = 0, count4 = 0, count5 = 0;
        if(e.getSource().equals(BACK))
        {
            this.dispose();
            new Login(5);
        }
        else if (e.getSource().equals(next)) {
            char[] x = password.getText().toString().toCharArray();
            for (int i = 0; i < password.getText().length(); i++) {
                if ((int) x[i] >= 65 && (int) x[i] <= 90)
                    count3 = 1;
                else if ((int) x[i] >= 97 && (int) x[i] <= 122)
                    count4 = 1;
                else if ((int) x[i] > 47 && (int) x[i] < 59)
                    count5 = 1;
            }
            if(firstname.getText().equals("")||firstname.getText().equals("First name"))
                JOptionPane.showMessageDialog(null, "Enter name", "Registration", JOptionPane.ERROR_MESSAGE);
            else if(username.getText().equals("")||username.getText().equals("email"))
                JOptionPane.showMessageDialog(null, "Enter Email", "Registration", JOptionPane.ERROR_MESSAGE);
            else if(!(username.getText().contains("@"))||!(username.getText().contains(".com")))
                JOptionPane.showMessageDialog(null, "Email must Contain @ and .com", "Registration", JOptionPane.ERROR_MESSAGE);
            else if(!(checker("allaccounts.txt", username)))
                     JOptionPane.showMessageDialog(null, "Email Already Exist", "Registration", JOptionPane.ERROR_MESSAGE);
            else if(password.getText().equals("")||password.getText().equals("password"))
                JOptionPane.showMessageDialog(null, "Enter Password", "Registration", JOptionPane.ERROR_MESSAGE);
           else if((password.getText().length()<8))
                JOptionPane.showMessageDialog(null, " Password must greater than 8 character", "Registration", JOptionPane.ERROR_MESSAGE);
            else if(count3!=1)
                JOptionPane.showMessageDialog(null, "Password Must Include Capital letter", "Registration", JOptionPane.ERROR_MESSAGE);
            else if(count4!=1)
                JOptionPane.showMessageDialog(null, "Password Must Include small letter", "Registration", JOptionPane.ERROR_MESSAGE);
            else if(count5!=1)
                JOptionPane.showMessageDialog(null, "Password Must Include  Digits", "Registration", JOptionPane.ERROR_MESSAGE);
            else if(!(password.getText().equals(confirmpassword.getText())))
                JOptionPane.showMessageDialog(null, "Password and confirm password not equal", "Registration", JOptionPane.ERROR_MESSAGE);
               else
            {
                JOptionPane.showMessageDialog(null, "Your Account Successfully Created","Registration", JOptionPane.INFORMATION_MESSAGE);
                    try {
                        FileWriter myWriter = new FileWriter("allaccounts.txt", true);
                        myWriter.write(firstname.getText());
                        myWriter.write("\n");
                        myWriter.write(lastname.getText());
                        myWriter.write("\n");
                        myWriter.write(username.getText());
                        myWriter.write("\n");
                        myWriter.write(password.getText());
                        myWriter.write("\n");
                        myWriter.close();
                        System.out.println("Successfully wrote to the file.");
                    } catch ( IOException ex) {
                        System.out.println("An error occurred.");
                        ex.printStackTrace();
                    }
                    String z=username.getText();
                    this.dispose();
                    new Choice(z);
            }
        }
   }
   public boolean checker(String file,JTextField username) {
        boolean count = true;
        try {
            File read = new File(file);
            Scanner myread = new Scanner(read);
            while (myread.hasNext()) {
                if (username.getText().equals(myread.next())) {
                    count = false;
                    break;
                }
            }
            myread.close();
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }
        return (count);
    }

    @Override
    public boolean checker() {
        return false;
    }

    @Override
    public void focusGained(FocusEvent e) {
        if(e.getSource()==firstname)
        {
            firstname.setBorder(BorderFactory.createLineBorder(Color.blue,2,true));
            if(firstname.getText().equals("First name"))
            {
                firstname.setText("");
            }
        }
        else if(e.getSource()==lastname)
        {
            lastname.setBorder(BorderFactory.createLineBorder(Color.blue,2,true));
            if(lastname.getText().equals("Last name(optional)"))
            {
                lastname.setText("");
            }
        }
        else if(e.getSource()==username)
        {
            username.setBorder(BorderFactory.createLineBorder(Color.blue,2,true));
            if(username.getText().equals("email"))
            {
                username.setText("");
            }
        }
        else if(e.getSource()==confirmpassword)
        {
            confirmpassword.setBorder(BorderFactory.createLineBorder(Color.blue,2,true));
            if(confirmpassword.getText().equals("confirm password"))
            {
                confirmpassword.setText("");
            }
        }
        else
        {
            password.setBorder(BorderFactory.createLineBorder(Color.black,1,true));
            if(password.getText().equals("password"))
            {
                password.setText("");
            }
        }
    }
    @Override
    public void focusLost(FocusEvent e) {
        if(e.getSource()==firstname)
        {
            firstname.setBorder(BorderFactory.createLineBorder(Color.black,1,true));
            if(firstname.getText().isEmpty())
            {
                firstname.setText("First name");
            }
        }
        else if(e.getSource()==lastname)
        {
            lastname.setBorder(BorderFactory.createLineBorder(Color.black,1,true));
            if(lastname.getText().isEmpty())
            {
                lastname.setText("Last name(optional)");
            }
        }
        else if(e.getSource()==username)
        {
            username.setBorder(BorderFactory.createLineBorder(Color.black,1,true));
            if(username.getText().isEmpty())
            {
                username.setText("email");
            }
        }
        else if(e.getSource()==confirmpassword)
        {
            confirmpassword.setBorder(BorderFactory.createLineBorder(Color.black,1,true));
            if(confirmpassword.getText().isEmpty())
            {
                confirmpassword.setText("confirm password");
            }
        }
        else
        {
            password.setBorder(BorderFactory.createLineBorder(Color.black,1,true));
            if(password.getText().isEmpty())
            {
                password.setText("password");
            }
        }
    }


}

