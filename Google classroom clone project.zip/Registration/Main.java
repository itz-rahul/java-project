package Registration;
import Teacher.*;

import java.io.FileNotFoundException;

public class Main{
    public static void main(String[] args) throws FileNotFoundException {
//        new joinclassform("Nope@gmail.com");
   Getstart input = new Getstart(5);
     // new Attendence("rahoolrathi@gmail.com","L  L  L");
//        new Classpage(5);
//        new allclassesspage();
//        new alljoinclass("Nope@gmail.com");
//        new peoplepage("RAHOOLRATHI@gmail.com");
//       new assignclasswork("rahoolrathi");
//       new classworkpage("ok");
//       new Attendence("ok");
//        new Signup(5);
//        new Choice("ok");
//       new allclassesspage("rahoolrathi@gmail.com");
//        new createclassform("rahoolrathi@gmail.com");
    }
}