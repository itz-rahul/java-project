package Registration;
import javax.swing.*;
public interface differentfuncationchacker {
    boolean checker(String x, JTextField y);
    boolean checker();
}
