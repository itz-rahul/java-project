package Registration;
import Teacher.allclassesspage;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
public class Login extends JFrame implements FocusListener,ActionListener,differentfuncationchacker {
    ImageIcon icon = new ImageIcon("icon.jpg");                           // single inheritance
    JLabel label = new JLabel();                                                  // multiple interface
    JTextField name = new JTextField("email");                                    // file handling
    JTextField password = new JTextField("password");                            // excaption handling
    JButton login = new JButton();
    JButton signup = new JButton();
public Login(int x) {
    buttonproperties();
    labelproperties();
    pageproperties();
}
                                                            //Fronted
protected void buttonproperties()
{
    signup.setBackground(Color.BLUE);
    signup.setText("Signup");
    signup.setForeground(Color.WHITE);
    signup.setFont(new Font("Arial", Font.BOLD, 10));
    signup.setBounds(300, 600, 150, 20);
    signup.setFocusPainted(false);
    signup.addActionListener(this);
    login.setBackground(Color.BLUE);
    login.setText("LOGIN");
    login.setForeground(Color.WHITE);
    login.setFont(new Font("Arial", Font.BOLD, 20));
    login.setBounds(220, 555, 240, 40);
    login.setFocusPainted(false);
    login.addActionListener(this);
    this.add(signup);
    this.add(login);
    name.setFont(new Font("Arial", Font.ITALIC, 25));
    password.setFont(new Font("Arial", Font.ITALIC, 25));
    name.addFocusListener(this);
    name.setForeground(Color.lightGray);
    name.setBorder(BorderFactory.createLineBorder(Color.black, 1));
    name.setBounds(220, 470, 240, 40);
    password.setBorder(BorderFactory.createLineBorder(Color.black, 1));
    password.setBounds(220, 512, 240, 40);
    password.addFocusListener(this);
    password.setForeground(Color.lightGray);
    this.add(password);
    this.add(name);
}
protected void labelproperties()
{
    label.setText("GOOGLE CLASSROOM CLONE");
    label.setVerticalTextPosition(JLabel.BOTTOM);
    label.setHorizontalTextPosition(JLabel.CENTER);
    label.setHorizontalAlignment(JLabel.CENTER);
    label.setVerticalAlignment(JLabel.CENTER);
    label.setForeground(Color.BLACK);
    label.setIconTextGap(50);
    label.setFont(new Font("Calibri Light", Font.ITALIC, 40));
    label.setIcon(icon);
    this.add(label);
}
    private void pageproperties()
    {
        ImageIcon icon = new ImageIcon("icon.jpg");
        this.setTitle("Registration");
        this.setSize(700,700);
        this.getContentPane().setBackground(Color.WHITE);
        this.setIconImage(icon.getImage());
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }                                                          //Backened
public boolean checker(String file,JTextField checked) {
        boolean count = false;
        File read = new File(file);
    Scanner myread = null;
    try {
        myread = new Scanner(read);
    } catch (FileNotFoundException e) {
        e.printStackTrace();
    }
    while (myread.hasNext()) {                                                 // allacount
                                                                                    //1*teacher and student file
            if (checked.getText().equals(myread.next())) {
                count = true;
                break;
            }
        }
        myread.close();
        return (count);
}

    @Override
    public boolean checker() {
        return false;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource().equals(signup))
        {
            this.dispose();
            new Signup(5);
        }
        else
        {
            try {
                if(checker("teacher.txt",name)&&checker("allaccounts.txt",password))
                {
                    this.dispose();
                       String x=name.getText();
                    new allclassesspage(x);
                }
                else if(!checker("teacher.txt",name))
                {
                    JOptionPane.showMessageDialog(null, "Email not Exist",
                            "Registration", JOptionPane.ERROR_MESSAGE);
                }
                else
                {
                    JOptionPane.showMessageDialog(null, "Incorrect Password",
                            "Registration", JOptionPane.ERROR_MESSAGE);

                }
            } catch (FileNotFoundException ex) {
                ex.printStackTrace();
            }
        }
    }


    @Override
    public void focusGained(FocusEvent e) {
    if(e.getSource()==name)
    {
        name.setBorder(BorderFactory.createLineBorder(Color.blue,2,true));
        if(name.getText().equals("email"))
        {
            name.setText("");
        }
    }
    else
    {
        password.setBorder(BorderFactory.createLineBorder(Color.blue,2,true));
        if(password.getText().equals("password"))
        {
            password.setText("");
        }
    }
    }
    @Override
    public void focusLost(FocusEvent e) {
        if(e.getSource()==name)
        {
            name.setBorder(BorderFactory.createLineBorder(Color.black,1,true));
            if(name.getText().isEmpty())
            {
                name.setText("email");
            }
        }
        else if(e.getSource()==password)
        {
            password.setBorder(BorderFactory.createLineBorder(Color.black,1,true));
            if(password.getText().isEmpty())
            {
                password.setText("password");
            }
        }
    }
}