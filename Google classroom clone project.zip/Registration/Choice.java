package Registration;
import javax.swing.*;
import Teacher.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
public class Choice extends JFrame implements ActionListener  {
JButton teacher=new JButton();
JLabel label=new JLabel();
ImageIcon icon = new ImageIcon("icon.jpg");
String x;
     Choice(String z)
    { buttonproperties();
        x=z;
        label.setIcon(icon);
        label.setHorizontalAlignment(JLabel.CENTER);
        label.setVerticalAlignment(JLabel.CENTER);
        this.add(label);
        pageproperties();
    }
    private void  buttonproperties()
    {
        teacher.setBackground(Color.BLUE);
        teacher.setText("Teacher");
        teacher.setForeground(Color.WHITE);
        teacher.setFont(new Font("Arial", Font.BOLD, 20));
        teacher.setBounds(270, 470, 150, 50);
        teacher.setFocusPainted(false);
        teacher.addActionListener(this);
        this.add(teacher);
    }
    private void pageproperties()
    {
        ImageIcon icon = new ImageIcon("icon.jpg");
        this.setTitle("Selection");
        this.setSize(700,700);
        this.getContentPane().setBackground(Color.WHITE);
        this.setIconImage(icon.getImage());
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }
    public void actionPerformed(ActionEvent e) {
if(e.getSource().equals(teacher))
{
    FileWriter myWriter = null;
    try {
        myWriter = new FileWriter("teacher.txt", true);
        myWriter.write(x);
        myWriter.write("\n");
        myWriter.close();
        File myObj = new File(x+".txt");
        if(myObj.createNewFile());
    } catch (IOException ex) {
        ex.printStackTrace();
    }
    this.dispose();
    new createclasspage(x);
}
     }
}