package Registration;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;                                         // Fronted
public class Getstart extends JFrame implements ActionListener {
    ImageIcon page1picture = new ImageIcon("Front.jpeg");                                 //*CONCEPTS
    JLabel page1label = new JLabel();
    JButton button = new JButton();                                                              //1)inheritance
    Border roundedBorder = new LineBorder(Color.GREEN, 1, true);            //2)interface
 public Getstart()                                                                               //3) polymorphism
    {

    }
    public Getstart(int x)
    {
        buttonproperties();
        page1label.setIcon(page1picture);
        this.add(page1label);
        pageproperties();
    }
    private void buttonproperties()
    {
        button.setText("GET STARTED");
        button.setForeground(Color.green);
        button.setFont(new Font("Arail", Font.PLAIN, 10));
        button.setBackground(Color.WHITE);
        button.setBounds(60, 120, 110, 25);
        button.setFocusPainted(false);
        button.setBorder(roundedBorder);
        button.addActionListener(this);
        this.add(button);
    }
    private void pageproperties()
    {
        ImageIcon icon = new ImageIcon("icon.jpg");
        this.setTitle("Google Classroom Clone");
        this.setSize(225,225);
        this.getContentPane().setBackground(Color.WHITE);
        this.setIconImage(icon.getImage());
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==button)
        {
            this.dispose();
            new Login(5);
        }
    }
}