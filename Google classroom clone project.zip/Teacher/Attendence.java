package Teacher;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.Scanner;

public class Attendence extends Classpage{
    private JButton Stream=new JButton();
    private JButton Classwork=new JButton();
    private  JButton People=new JButton();
    private JButton attendence=new JButton();
    private JButton back=new JButton();
    private JButton submit=new JButton();
    private JPanel main=new JPanel();
    Date date = new Date();
    SimpleDateFormat dateFormat= new SimpleDateFormat("dd/MMM/yyyy");
    String dateOnly = dateFormat. format(date);
    DefaultTableModel tableModel = new DefaultTableModel();
    JTable table=new JTable(tableModel);
    String teachermail="";
    String data;
    public Attendence(String mail,String data)
    {

        this.data=data;
        teachermail=mail;
        buttonproperties(Stream,Classwork,People,attendence,back);
        panel2();
        Jtableproperties();
        pageproperies();
    }
    private void Jtableproperties()
    {
        tableModel.addColumn("S.No");
        tableModel.addColumn("Name");
        tableModel.addColumn(dateOnly);
        table.setBounds(30, 40, 700, 600);
        table.getColumnModel().getColumn(0).setPreferredWidth(5);
        table.getColumnModel().getColumn(1).setPreferredWidth(100);
        table.getColumnModel().getColumn(2).setPreferredWidth(5);
        JScrollPane sp = new JScrollPane(table);
        table.setBackground(Color.white);
        this.add(sp);
        submit.setPreferredSize(new Dimension(150,40));
        submit.setText("Submit");
        submit.setBackground(Color.blue);
        submit.setForeground(Color.white);
        System.out.println(data);
        System.out.println(data);
        submit.setFocusPainted(false);
        File myobj=new File("dates.txt");
        try {
            Scanner myread=new Scanner(myobj);
            while(myread.hasNextLine())
            {
                if(data.equals(myread.nextLine())&&teachermail.equals(myread.nextLine())&&dateOnly.equals(myread.nextLine()))
                {
                    System.out.println("date:"+dateOnly);
                    submit.setEnabled(false);
                    break;
                }
            }
            myread.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        submit.addActionListener(this);
        submit.setFont(new Font("Arial",Font.BOLD,30));
        main.add(sp);
        main.add(submit);
        this.add(main);
        main.setBackground(Color.white);
        main.setPreferredSize(new Dimension(500,800));
       // submit.setLayout(new  BoxLayout(submit, BoxLayout.PAGE_AXIS));
    }
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==submit)
        {
            JOptionPane.showMessageDialog(null,"Submited","Attendence",JOptionPane.INFORMATION_MESSAGE);
            FileWriter writes= null;
            try {
                System.out.println(data+"\n");
                System.out.println(teachermail+"\n");
                System.out.println(dateOnly+"\n");
                writes = new FileWriter("dates.txt",true);
                writes.write(data+"\n");
                writes.write(teachermail+"\n");
                writes.write(dateOnly);
                writes.write("\n");
                writes.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
             this.dispose();
            new Classpage(teachermail,data);
        }
        else if (e.getSource().equals(Stream)) {
            this.dispose();
            new Classpage(teachermail,data);
        }
        else if(e.getSource().equals(Classwork))
        {
            this.dispose();
            new classworkpage(teachermail,data);
        }
        else if(e.getSource().equals(People))
        {
            this.dispose();
            new peoplepage(teachermail,data);
        }
        else if(e.getSource().equals(attendence))
        {
            this.dispose();
            new Attendence(teachermail,data);
        }
        else if(e.getSource().equals(back)){
            this.dispose();
            try {
                new allclassesspage(teachermail);
            } catch (FileNotFoundException ex) {
                ex.printStackTrace();
            }
        }

    }
}
