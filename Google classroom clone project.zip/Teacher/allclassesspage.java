package Teacher;
import Registration.Login;
import org.w3c.dom.ls.LSOutput;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Scanner;
public class allclassesspage extends Classpage {
    public   JPanel pagepanel = new JPanel();
   private JButton[] button = new JButton[30];
    private JPanel[] panel = new JPanel[30];
    private JButton Create = new JButton();
    private JButton signout=new JButton();
    private String z;
    public allclassesspage()
    {

    }
    public allclassesspage(String x) throws FileNotFoundException {
        z = x;
        panelcreating();
        pagepanelproperties();
        createbuttton(signout,"Signout",200,690,270,70);
        createbuttton(Create,"Create",680,690,250,70);
        pageproperies();
    }
    public void createbuttton(JButton create,String title,int x,int y,int w,int h)
    {
        create.setBackground(Color.blue);
        create.setText(title);
        create.setForeground(Color.white);
        create.setFont(new Font("Arial", Font.PLAIN, 25));
        create.setBounds(x,y,w,h);
        create.setVerticalTextPosition(JButton.BOTTOM);
        create.setFocusPainted(false);
        create.setBorder(BorderFactory.createLineBorder(Color.WHITE));
        create.addActionListener(this);
        this.add(create);
    }
    public void pagepanelproperties() {
        pagepanel.setBackground(Color.white);
        pagepanel.setBorder(BorderFactory.createLineBorder(Color.lightGray, 1));
        pagepanel.setPreferredSize(new Dimension(1368, 650));
        this.add(pagepanel);
    }

    public  int countlines(String email) {
        int count = 0;
        try {
            File checklines = new File(email+".txt");
            Scanner countlines = new Scanner(checklines);
            while (countlines.hasNextLine()) {
                countlines.nextLine();
                count++;
            }
            countlines.close();
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }
        return (count);
    }
    public void panelcreating() {
        File read = new File(z+".txt");
        Scanner myobj = null;
        try {
            myobj=  new Scanner(read);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        int count=1;
        for (int i = 0; i < (countlines(z))/4; i++) {
            panel[i] = new JPanel();
            button[i] = new JButton();
            button[i].setFocusPainted(false);
            button[i].setVerticalTextPosition(JButton.CENTER);
            button[i].setHorizontalAlignment(JButton.CENTER);
            button[i].setForeground(Color.white);
            button[i].setFont(new Font("Arial", Font.BOLD, 20));
            button[i].setBackground(new Color(0, 191, 255));
            button[i].setBorder(BorderFactory.createLineBorder(new Color(0, 191, 255), 1));
            panel[i].setBackground(Color.WHITE);
            panel[i].setBorder(BorderFactory.createLineBorder(Color.lightGray, 1));
            button[i].setPreferredSize(new Dimension(456, 70));
            panel[i].setPreferredSize(new Dimension(250, 100));
            panel[i].add(button[i]);
            pagepanel.add(panel[i]);
            button[i].addActionListener(this);
             count=1;
             String allData = "";
            while (true) {
                assert myobj != null;
                if (!myobj.hasNext()) break;
                if(count==1||count==2||count==3) {
                    String Data;
                  Data =myobj.nextLine();
                  allData+=Data;
                  allData+="  ";
                }
                else {
                    String data=myobj.nextLine();
                    break;
                }

                count++;
            }
            button[i].setText(allData);
        }
        assert myobj != null;
        myobj.close();
    }
    public void actionPerformed(ActionEvent e) {
    if(e.getSource().equals(Create))
    {
        System.out.println("ok");
        this.dispose();
        new createclassform(z);
    }
    else if(e.getSource().equals(signout))
        {
            this.dispose();
            new Login(5);
        }
    else
    {
        String data = null;
        for(int i=0;i<(countlines(z))/4;i++)
        {
            if(e.getSource().equals(button[i]))
            {
               
                data=button[i].getText();
               break;
            }
        }
        System.out.println(data);
        this.dispose();
        new Classpage(z,data);
    }
    }
}

