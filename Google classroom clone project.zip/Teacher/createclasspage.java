package Teacher;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class createclasspage extends JFrame implements ActionListener {
   private final JButton createclass=new JButton();
    String t;
   public createclasspage()
   {

   }
    public createclasspage(String y)
    {
        t=y;
        buttonproperties(createclass,"Create Class");
        this.add(createclass);
        pageproperties("Create class",700,700);
    }
    public void buttonproperties(JButton createclass,String title)
    {
        createclass.addActionListener(this);
        createclass.setBackground(Color.BLUE);
        createclass.setText(title);
        createclass.setForeground(Color.WHITE);
        createclass.setFont(new Font("Arial", Font.BOLD, 20));
        createclass.setBounds(300, 600, 120, 50);
        createclass.setFocusPainted(false);
    }
    public void pageproperties(String title,int w,int h)
    {
        ImageIcon icon = new ImageIcon("icon.jpg");
        this.setTitle(title);
        this.setSize(w,h);
        this.getContentPane().setBackground(Color.WHITE);
        this.setIconImage(icon.getImage());
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
        this.setResizable(false);
        this.setLayout( new GridBagLayout() );
        this.add(createclass, new GridBagConstraints());
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource().equals(createclass))
        {
            this.dispose();
            new createclassform(t);
        }
    }
}