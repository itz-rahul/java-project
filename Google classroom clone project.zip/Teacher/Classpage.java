package Teacher;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
public class Classpage extends JFrame implements ActionListener {
    private  JPanel buttonpanel=new JPanel();
    private  JPanel labelpanel=new JPanel();
    private JLabel Labelpanellabel=new JLabel();
    private JPanel codepanel=new JPanel();
    private JLabel codelabel=new JLabel();
    private JPanel teacherannoucment=new JPanel();
    private JButton Back=new JButton();
    private JButton stream=new JButton();
    private JButton classwork=new JButton();
    private  JButton people=new JButton();
    private JButton Attendence=new JButton();
    private JButton post=new JButton();
    private JButton cancel=new JButton();
    private JTextField announcmentsome=new JTextField();
    String z,data;
    public Classpage()
    {

    }
    public Classpage(String x,String data)
    {
        this.data=data;
        z=x;
        buttonproperties(stream,classwork,people,Attendence,Back);
        panel2();
        codepanel();
        panelsproperties(data);
        codepanel();
        pageproperies();
    }
    public void buttonproperties(JButton stream,JButton classwork,JButton people,JButton Attendence,JButton Back)
    {
        stream.setBorder(BorderFactory.createLineBorder(Color.WHITE));
        stream.setBackground(Color.white);
        stream.setText("Stream");
        stream.setVerticalTextPosition(JButton.BOTTOM);
        stream.setForeground(Color.black);
        stream.setFont(new Font("Arial", Font.PLAIN, 15));
        stream.setBounds(100, 15, 90, 50);
        stream.setFocusPainted(false);
        stream.addActionListener(this);
        classwork.setBorder(BorderFactory.createLineBorder(Color.WHITE));
        classwork.setBackground(Color.white);
        classwork.setText("  Classwork");
        classwork.setForeground(Color.black);
        classwork.setVerticalTextPosition(JButton.BOTTOM);
        classwork.setFont(new Font("Arial", Font.PLAIN, 15));
        classwork.setBounds(250, 15, 90, 50);
        classwork.setFocusPainted(false);
        classwork.addActionListener(this);
        people.setBorder(BorderFactory.createLineBorder(Color.WHITE));
        people.setBackground(Color.white);
        people.setText("   People");
        people.setVerticalTextPosition(JButton.BOTTOM);
        people.setForeground(Color.black);
        people.setFont(new Font("Arial", Font.PLAIN, 15));
        people.setBounds(400, 15, 90, 50);
        people.setFocusPainted(false);
        people.addActionListener(this);
        Attendence.setBorder(BorderFactory.createLineBorder(Color.WHITE));
        Attendence.setBackground(Color.white);
        Attendence.setText("   Attendence");
        Attendence.setForeground(Color.black);
        Attendence.setFont(new Font("Arial", Font.PLAIN, 15));
        Attendence.setBounds(700, 15, 120, 50);
        Attendence.setVerticalTextPosition(JButton.BOTTOM);
        Attendence.setFocusPainted(false);
        Attendence.addActionListener(this);
        Attendence.setBorder(BorderFactory.createLineBorder(Color.WHITE));
        Back.setBackground(Color.WHITE);
        Back.setText("   Back");
        Back.setForeground(Color.black);
        Back.setFont(new Font("Arial", Font.PLAIN, 15));
        Back.setBounds(900, 300, 120, 50);
        Back.setVerticalTextPosition(JButton.BOTTOM);
        Back.setFocusPainted(false);
        Back.setBorder(BorderFactory.createLineBorder(Color.WHITE));
        Back.addActionListener(this);
        buttonpanel.add(stream);
        buttonpanel.add(classwork);
        buttonpanel.add(people);
        buttonpanel.add(Attendence);
        buttonpanel.add(Back);
    }
    public void panel2()
    {
        buttonpanel.setBackground(Color.white);
        buttonpanel.setBorder(BorderFactory.createLineBorder(Color.lightGray, 1));
        buttonpanel.setPreferredSize(new Dimension(1368, 100));
        this.add(buttonpanel);
    }
    public void panelsproperties(String data) {
        Labelpanellabel.setForeground(Color.white);
        Labelpanellabel.setFont(new Font("Arial",Font.PLAIN,50));
        Labelpanellabel.setText(data);
        Labelpanellabel.setVerticalTextPosition(JLabel.CENTER);
        labelpanel.add(Labelpanellabel);
        labelpanel.setBackground(new Color(0, 191, 255));
        labelpanel.setBorder(BorderFactory.createLineBorder(Color.lightGray, 1));
        labelpanel.setPreferredSize(new Dimension(1100, 240));
        this.add(labelpanel);
        teacherannoucment.setBackground(Color.white);
        teacherannoucment.setBorder(BorderFactory.createLineBorder(Color.lightGray, 1));
        teacherannoucment.setPreferredSize(new Dimension(800, 200));
        this.add(teacherannoucment);
        announcmentsome.setPreferredSize(new Dimension(800, 150));
        announcmentsome.setBorder(BorderFactory.createLineBorder(Color.lightGray, 1));
        announcmentsome.setText("Announce something to your class");
        announcmentsome.setFont(new Font("Arial", Font.ITALIC, 15));
        teacherannoucment.add(announcmentsome);
        cancel.setBorder(BorderFactory.createLineBorder(Color.blue));
        cancel.setBackground(Color.BLUE);
        cancel.setText("Cancel");
        cancel.setVerticalTextPosition(JButton.CENTER);
        cancel.setForeground(Color.white);
        cancel.setFont(new Font("Arial", Font.BOLD, 20));
        cancel.setBounds(400, 20, 200, 70);
        cancel.setFocusPainted(false);
        cancel.addActionListener(this);
        teacherannoucment.add(cancel);
        post.setBorder(BorderFactory.createLineBorder(Color.blue));
        post.setBackground(Color.BLUE);
        post.setText("Post");
        post.setVerticalTextPosition(JButton.CENTER);
        post.setForeground(Color.white);
        post.setFont(new Font("Arial", Font.BOLD, 20));
        post.setBounds(400, 20, 200, 70);
        post.setFocusPainted(false);
       post.addActionListener(this);
        teacherannoucment.add(post);
    }
    private  void codepanel()
    {
        codelabel.setForeground(Color.BLACK);
        codelabel.setFont(new Font("Arial",Font.PLAIN,70));
        File Read=new File(z+".txt");
        try {
            Scanner myobj=new Scanner(Read);
            while(myobj.hasNext())
            {
                String data=myobj.nextLine();
                data=myobj.nextLine();
                data=myobj.nextLine();
                codelabel.setText(myobj.nextLine());
            }
            myobj.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        codelabel.setVerticalTextPosition(JLabel.CENTER);
        codepanel.add(codelabel);
        codepanel.setBackground(Color.white);
        codepanel.setBorder(BorderFactory.createLineBorder(Color.lightGray, 1));
        codepanel.setPreferredSize(new Dimension(300, 240));
        this.add(codepanel);
    }
    public  void pageproperies()
    {
        ImageIcon icon = new ImageIcon("icon.jpg");
        this.getContentPane().setBackground(Color.WHITE);
        this.setIconImage(icon.getImage());
        this.setTitle("GooGle Classroom CLone");
        this.setSize(1368, 768);
        this.setResizable(false);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
        this.setLayout(new FlowLayout());
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(stream)) {
            this.dispose();
            new Classpage(z,data);
        }
        else if(e.getSource().equals(classwork))
        {
             this.dispose();
             new classworkpage(z,data);
        }
        else if(e.getSource().equals(people))
        {
            this.dispose();
            new peoplepage(z,data);
        }
        else if(e.getSource().equals(Attendence))
        {
                this.dispose();
                new Attendence(z,data);
        }
        else if(e.getSource().equals(post))
        {
            if(announcmentsome.getText().equals("")||(announcmentsome.getText().equals("Announce something to your class")))
            JOptionPane.showMessageDialog(null,"Invalid","Announcement",JOptionPane.INFORMATION_MESSAGE);
            else {
                JOptionPane.showMessageDialog(null, "Post successfully", "Announcement", JOptionPane.INFORMATION_MESSAGE);
                try {
                    FileWriter writer =new FileWriter(z+"announcements.txt");
                    writer.write(announcmentsome.getText());
                    writer.write("End");
                    writer.write("\n");
                    writer.close();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
                this.dispose();
                new Classpage(z,data);
            }
        }
        else if(e.getSource().equals(cancel))
        {
               this.dispose();
              new Classpage(z,data);
        }
        else if(e.getSource().equals(Back)){
           this.dispose();
            try {
                new allclassesspage(z);
            } catch (FileNotFoundException ex) {
                ex.printStackTrace();
            }
        }
    }
}
