package Teacher;
import Registration.Signup;
import Registration.differentfuncationchacker;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.io.*;
import java.util.Random;
import java.util.Scanner;
public class createclassform extends JFrame implements ActionListener, FocusListener, differentfuncationchacker {
    JLabel label = new JLabel();
    JTextField classname = new JTextField("Class name(required)");
    JTextField section = new JTextField("Section(required)");
    JTextField subject = new JTextField("Subject(required)");
    JTextField Room = new JTextField("Room");
    JButton create = new JButton();
    //Choice email=new Choice();
    String z;
    public createclassform(String y)
    {
        z=y;
        butonproperties();
        textfiled();
        pageproperties();
    }
    private void butonproperties()
    {
        create.addActionListener(this);
        create.setBackground(Color.BLUE);
        create.setText("Create");
        create.setForeground(Color.WHITE);
        create.setFont(new Font("Arial", Font.BOLD, 20));
        create.setBounds(240, 430, 120, 50);
        create.setFocusPainted(false);
        this.add(create);
    }

    private void pageproperties()
    {
        ImageIcon icon = new ImageIcon("icon.jpg");
        this.getContentPane().setBackground(Color.WHITE);
        this.setIconImage(icon.getImage());
        this.setTitle("Create Class");
        this.setSize(700, 700);
        this.setResizable(false);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }
    private  void textfiled()
    {
        classname.setFont(new Font("Arial", Font.ITALIC, 15));
        section.setFont(new Font("Arial", Font.ITALIC, 15));
        subject.setFont(new Font("Arial", Font.ITALIC, 15));
        Room.setFont(new Font("Arial", Font.ITALIC, 15));
        classname.setBounds(90, 170, 380, 40);
        section.setBounds(90, 230, 380, 40);
        subject.setBounds(90, 290, 380, 40);
        Room.setBounds(90, 350, 380, 40);
        classname.addFocusListener(this);
        section.addFocusListener(this);
        subject.addFocusListener(this);
        Room.addFocusListener(this);
        classname.setForeground(Color.lightGray);
        subject.setForeground(Color.lightGray);
        section.setForeground(Color.lightGray);
        Room.setForeground(Color.lightGray);
        this.add(classname);
        this.add(section);
        this.add(subject);
        this.add(Room);
        this.add(label);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
if(e.getSource().equals(create))
{
       if(classname.getText().equals("")||classname.getText().equals("Class name(required)"))
           JOptionPane.showMessageDialog(null,"Insert Class Name", "Class Form",JOptionPane.ERROR_MESSAGE);

    else if(section.getText().equals("")||section.getText().equals("Section(required)"))
        JOptionPane.showMessageDialog(null,"Insert Section Name", "Class Form",JOptionPane.ERROR_MESSAGE);
    else if(subject.getText().equals("")||subject.getText().equals("Subject(required)"))
        JOptionPane.showMessageDialog(null,"Insert Subject Name", "Class Form",JOptionPane.ERROR_MESSAGE);
       else if( !checker(z,classname))
       {
          JOptionPane.showMessageDialog(null,"Class name already Exist","Class Form",JOptionPane.ERROR_MESSAGE);
       }
       else
       {
           JOptionPane.showMessageDialog(null,"successfully created class","Class Form",JOptionPane.INFORMATION_MESSAGE);
           try {
               Writer mywriter=new FileWriter(z+".txt",true);
               mywriter.write(classname.getText());
               mywriter.write("\n");
               mywriter.write(section.getText());
               mywriter.write("\n"+subject.getText()+"\n");
               mywriter.close();
           } catch (IOException ex) {
               ex.printStackTrace();
           }
           codegenrator();
           this.dispose();
           String data=classname.getText()+"  "+section.getText()+"  "+subject.getText();
           new Classpage(z,data);
       }
}
    }
    public boolean checker(String file,JTextField classname)
    {
        boolean count = true;

        File check = new File(file + ".txt");
        try {
            Scanner myread = new Scanner(check);
            while (myread.hasNext()) {
                if (classname.getText().equals(myread.next())) {
                    count = false;
                    break;
                }
            }
            myread.close();
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }
        return (count);
    }

    @Override
    public boolean checker() {
        return false;
    }

    public void codegenrator() {
        String character = "&a1!b2c3$d4e5f6#g7hijk$lmnop@5qr8stuv0wxyz89";
        String code = "";
        int codelenth = 7;
        Random rand = new Random();
        char text[] = new char[codelenth];
        for (int i = 0; i < codelenth; i++) {
            text[i] = character.charAt(rand.nextInt(character.length()));
        }
        for (int i = 0; i < text.length; i++) {
            code += text[i];
        }

        int count = 0;
        File check = new File("allcodes.txt");
        try {
            Scanner myread = new Scanner(check);
            while (myread.hasNext()) {
                if (code.equals(myread.next())) {
                    count = 1;
                    break;
                }
            }
            myread.close();
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }

        if (count == 1) {
            createclassform used = new createclassform(z);
            used.codegenrator();
        } else {
            try {
                FileWriter writecode2 = new FileWriter( "allcodes.txt", true);
                writecode2.write(code);
                writecode2.write("\n");
                writecode2.write(z);
                writecode2.write("\n");
                writecode2.close();
            FileWriter writecode1 = new FileWriter(z + ".txt", true);
            writecode1.write(code);
            writecode1.write("\n");
                writecode1.close();

            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }
    @Override
    public void focusGained(FocusEvent e) {
        if(e.getSource()==classname)
        {
            classname.setBorder(BorderFactory.createLineBorder(Color.blue,2,true));
            if(classname.getText().equals("Class name(required)"))
            {
                classname.setText("");
            }

        }
        else if(e.getSource()==section)
        {
            section.setBorder(BorderFactory.createLineBorder(Color.blue,2,true));
            if(section.getText().equals("Section(required)"))
            {
                section.setText("");
            }
        }
        else if(e.getSource()==subject)
        {
            subject.setBorder(BorderFactory.createLineBorder(Color.blue,2,true));
            if(subject.getText().equals("Subject(required)"))
            {
                subject.setText("");
            }
        }
        else
        {
            Room.setBorder(BorderFactory.createLineBorder(Color.blue,2,true));
            if(Room.getText().equals("Room"))
            {
                Room.setText("");
            }
        }
    }
    @Override
    public void focusLost(FocusEvent e) {
        if(e.getSource()==classname)
        {
            classname.setBorder(BorderFactory.createLineBorder(Color.black,1,true));
            if(classname.getText().isEmpty())
            {
                classname.setText("Class name(required)");
            }
        }
        else if(e.getSource()==section)
        {
            section.setBorder(BorderFactory.createLineBorder(Color.black,1,true));
            if(section.getText().isEmpty())
            {
                section.setText("Section(required)");
            }
        }
        else if(e.getSource()==subject)
        {
            subject.setBorder(BorderFactory.createLineBorder(Color.black,1,true));
            if(subject.getText().isEmpty())
            {
                subject.setText("Subject(required)");
            }
        }
        else
        {
            Room.setBorder(BorderFactory.createLineBorder(Color.black,1,true));
            if(Room.getText().isEmpty())
            {
                Room.setText("Room");
            }
        }
    }
}