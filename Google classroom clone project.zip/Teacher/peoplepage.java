package Teacher;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
public class peoplepage extends Classpage {
    private JButton Stream=new JButton();
    private JButton Classwork=new JButton();
    private  JButton People=new JButton();
    private JButton attendence=new JButton();
    private JButton back=new JButton();
    JPanel mainpanel=new JPanel();
    JPanel teacherpanel=new JPanel();
    JLabel teacherlabel=new JLabel();
    JLabel studentlabel=new JLabel();
    JLabel Teachermail= new JLabel();
    JPanel Panels[]=new JPanel[30];
    JLabel labels[]=new JLabel[30];
    String teachermail="",data;
  public peoplepage(String email,String data)  {
        teachermail=email;
        this.data=data;
        buttonproperties( Stream, Classwork, People, attendence,back);
      panel2();
      try {
          mainpanelproperties();
      } catch (FileNotFoundException e) {
          e.printStackTrace();
      }

        pageproperies();
    }
    private void mainpanelproperties() throws FileNotFoundException {
        File myobj=new File(teachermail+"allstudents");
        if(!(myobj.exists()))
        {
            try {
                myobj.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        Scanner read =read=new Scanner(myobj);
        System.out.println(count());
        mainpanel.add(studentlabel);
        for(int i=0;i<count();i++)
        {
            Panels[i]=new JPanel();
            labels[i]=new JLabel();
            Panels[i].setBackground(Color.WHITE);
            Panels[i].setBorder(BorderFactory.createLineBorder(Color.white, 1,true));
            Panels[i].setPreferredSize(new Dimension(600, 30));
            labels[i].setFont(new Font("Arial", Font.PLAIN, 20));
            labels[i].setPreferredSize(new Dimension(600,25));
            labels[i].setVerticalAlignment(SwingConstants.TOP);
            labels[i].setBorder(BorderFactory.createEmptyBorder( -3 , 0, 0, 0 ));
            Panels[i].add(labels[i]);
                while (read.hasNextLine())
                {
                    labels[i].setText("    "+read.nextLine());
                    break;
                }
            mainpanel.add(Panels[i]);
        }
        Teachermail.setPreferredSize(new Dimension(600,50));
        Teachermail.setFont(new Font("Arial", Font.PLAIN, 20));
        Teachermail.setForeground(Color.darkGray);
       Teachermail.setText("   "+teachermail);
        teacherpanel.add(Teachermail);
        teacherlabel.setPreferredSize(new Dimension(600,50));
        teacherlabel.setFont(new Font("Arial", Font.PLAIN, 35));
        teacherlabel.setForeground(new Color(30,144,255));
        teacherlabel.setBorder(BorderFactory.createMatteBorder(0,0,1,0,Color.blue));
        teacherlabel.setText("Teachers");
        teacherpanel.add(teacherlabel);
        teacherpanel.add(Teachermail);
        this.add(teacherpanel);
        read.close();
        setFont(new Font("Arial", Font.PLAIN, 20));
        studentlabel.setPreferredSize(new Dimension(600,40));
        studentlabel.setVerticalAlignment(SwingConstants.TOP);
        studentlabel.setBorder(BorderFactory.createMatteBorder(0,0,1,0,Color.blue));
        studentlabel.setText("Students                                          "+count());
        studentlabel.setForeground(new Color(30,144,255));
        studentlabel.setFont(new Font("Arial", Font.PLAIN, 35));
        mainpanel.setBackground(Color.WHITE);
        mainpanel.setBorder(BorderFactory.createLineBorder(Color.white, 1));
        mainpanel.setPreferredSize(new Dimension(700, 500));
        this.add(mainpanel);
        teacherpanel.setBackground(Color.WHITE);
        teacherpanel.setBorder(BorderFactory.createLineBorder(Color.white, 1));
        teacherpanel.setPreferredSize(new Dimension(700, 100));
    }
    private int count() throws FileNotFoundException {int count=0;
        File myobj1=new File(teachermail+"allstudents");
        Scanner read=new Scanner(myobj1);
        {
               while(read.hasNextLine())
               {
                   read.nextLine();
                   count++;                              /////filing backened
               }
        }
            return (count);
    }
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(Stream)) {
            this.dispose();
            new Classpage(teachermail,data);
        }
        else if(e.getSource().equals(Classwork))
        {
            this.dispose();
            new classworkpage(teachermail,data);
        }
        else if(e.getSource().equals(People))
        {
            this.dispose();
            new peoplepage(teachermail,data);
        }
        else if(e.getSource().equals(attendence))
        {
            this.dispose();
            new Attendence(teachermail,data);
        }
        else if(e.getSource().equals(back)){
            this.dispose();
            try {
                new allclassesspage(teachermail);
            } catch (FileNotFoundException ex) {
                ex.printStackTrace();
            }
        }
    }
}