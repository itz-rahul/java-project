package Teacher;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
public class assignclasswork extends classworkpage implements FocusListener {
    private JPanel classwork=new JPanel();
    private JTextField title=new JTextField("Title");
    private JTextField  instructions=new JTextField("Instruction(Optional)");
    private JButton assign=new JButton();
    private JButton cancel=new JButton();
    private JButton back=new JButton();
    private String te;
    String data;
    public assignclasswork(String teachermail,String data)
    {

        this.data=data;
        te=teachermail;
        this.add(back);
        Jpanelproperties();
        back.addActionListener(this);
        back.setBackground(Color.BLUE);
        back.setText("Back");
        back.setForeground(Color.WHITE);
        back.setFont(new Font("Arial", Font.BOLD, 20));
        back.setBounds(0,10,200,80);
        back.setFocusPainted(false);
        pageproperies();
    }
    private void Jpanelproperties()
    {
        cancel.addActionListener(this);
        cancel.setBackground(Color.BLUE);
        cancel.setText("Cancel");
        cancel.setForeground(Color.WHITE);
        cancel.setFont(new Font("Arial", Font.BOLD, 20));
        cancel.setPreferredSize(new Dimension(100,40));
        cancel.setFocusPainted(false);
        assign.addActionListener(this);
        assign.setBackground(Color.BLUE);
        assign.setText("Assign");
        assign.setForeground(Color.WHITE);
        assign.setFont(new Font("Arial", Font.BOLD, 20));
        assign.setPreferredSize(new Dimension(100,40));
        assign.setFocusPainted(false);
        instructions.setBackground(Color.WHITE);
        instructions.setForeground(Color.lightGray);
        instructions.setFont(new Font("Arial", Font.PLAIN, 30));
        title.setFont(new Font("Arial", Font.PLAIN, 40));
        instructions.setPreferredSize(new Dimension(800,300));
        instructions.setBorder(BorderFactory.createLineBorder(Color.black, 1));
        instructions.addFocusListener(this);
        classwork.add(title);
       classwork.add(instructions);
        title.setBackground(Color.WHITE);
        title.setForeground(Color.lightGray);
        title.setPreferredSize(new Dimension(800,50));
        title.setBorder(BorderFactory.createLineBorder(Color.black, 1));
        title.addFocusListener(this);
        classwork.add(cancel);
        classwork.add(assign);
        classwork.setBackground(Color.WHITE);
        classwork.setBorder(BorderFactory.createLineBorder(Color.lightGray, 1));
        classwork.setPreferredSize(new Dimension(900, 500));
        this.add(classwork);

    }
    @Override
    public void focusGained(FocusEvent e) {
        if(e.getSource()==title)
        {
            title.setBorder(BorderFactory.createLineBorder(Color.blue,2,true));
            if(title.getText().equals("Title"))
            {
                title.setText("");
            }

        }
        else if(e.getSource()==instructions)
        {
            instructions.setBorder(BorderFactory.createLineBorder(Color.blue,2,true));
            if(instructions.getText().equals("Instruction(Optional)"))
            {
                instructions.setText("");
            }
        }

    }
    @Override
    public void focusLost(FocusEvent e) {
        if(e.getSource()==title)
        {
            title.setBorder(BorderFactory.createLineBorder(Color.black,1,true));
            if(title.getText().isEmpty())
            {
                title.setText("Title");
            }
        }
        else if(e.getSource()==instructions)
        {
            instructions.setBorder(BorderFactory.createLineBorder(Color.black,1,true));
            if(instructions.getText().isEmpty())
            {
                instructions.setText("Instruction(Optional)");
            }
        }
    }
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==cancel)
        {
          this.dispose();
          new assignclasswork(te,data);

       }
        else if(e.getSource()==assign)
        {
            try {
                if(assignwork())
                {
                    this.dispose();
                    new classworkpage(te,data);
                }
                else
                {
                    JOptionPane.showMessageDialog(null, "Enter Title", "Classwork", JOptionPane.ERROR_MESSAGE);
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        else if(e.getSource()==back) {
            this.dispose();
            new classworkpage(te,data);
        }
    }
    private boolean assignwork() throws IOException {    /// backned funcation
        if(title.getText().equals("")||title.getText().equals("Title")||title.getText().equals("title")) {

            return (false);
        }
        else
        {

            FileWriter writer=new FileWriter(te+"classwork",true);
            writer.write(title.getText()+"\n");
            if(!(instructions.equals("")||instructions.equals("Instruction(Optional)")||instructions.equals("instruction(Optional)"))) {
                writer.write(instructions.getText() + "\n");
                writer.write("End"+"\n");
            }
            else
                writer.write("End"+"\n");
            writer.close();
        }
        return (true);
    }
}
