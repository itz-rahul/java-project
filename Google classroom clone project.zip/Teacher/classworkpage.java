package Teacher;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
public class classworkpage extends Classpage{
    private JButton Stream=new JButton();
    private JButton Classwork=new JButton();
    private  JButton People=new JButton();
    private JButton attendence=new JButton();
    private JButton back=new JButton();
    private  JButton Create=new JButton();
    String teachermail="";
    private JPanel panels[]= new JPanel[30];
    private JLabel labels[]=new JLabel[30];
    private JPanel mainpanel= new JPanel();
    String data;
    classworkpage()
    {
    }
    public classworkpage(String z,String data)
    {
        this.data=data;
        buttonproperties(Stream,Classwork,People,attendence,back);
        panel2();
        teachermail=z;
        Create.addActionListener(this);
        Create.setBackground(Color.BLUE);
        Create.setText("+ Create");
        Create.setBorder(BorderFactory.createLineBorder(Color.blue,1,true));
        Create.setForeground(Color.WHITE);
        Create.setFont(new Font("Arial", Font.BOLD, 20));
        Create.setBounds(0,10,300,80);
        Create.setFocusPainted(false);
        panelcreating();
        this.add(Create);
        pageproperies();
    }
    private void panelcreating() {
        File myobj1=new File(teachermail+"classwork");
        Scanner read1=null;
        try {
            System.out.println(teachermail);
            myobj1.createNewFile();
            read1=new Scanner(myobj1);
        } catch (IOException e) {
            e.printStackTrace();
        }

        for(int i=0;i<countlines();i++)
     {
         panels[i]=new JPanel();
         labels[i]=new JLabel();
         panels[i].setBackground(new Color(30,144,255));
         panels[i].setBorder(BorderFactory.createLineBorder(Color.blue, 1,true));
         panels[i].setPreferredSize(new Dimension(1100, 50));
         labels[i].setFont(new Font("Arial", Font.PLAIN, 30));
         labels[i].setPreferredSize(new Dimension(1100,50));
         labels[i].setVerticalAlignment(SwingConstants.TOP);
         labels[i].setBorder(BorderFactory.createEmptyBorder( -3 /*top*/, 0, 0, 0 ));
         labels[i].setBackground(Color.BLUE);
         panels[i].add(labels[i]);
         mainpanel.add(panels[i]);
     }
        panels[0].setBorder(BorderFactory.createLineBorder(Color.white, 1,true));
        panels[0].setBackground(Color.WHITE);
        mainpanel.setBackground(Color.WHITE);
        mainpanel.setBorder(BorderFactory.createLineBorder(Color.white, 1));
        mainpanel.setPreferredSize(new Dimension(1300, 500));
        this.add(mainpanel);
        int i=0;
        while(read1.hasNextLine()) {
            if (i == 0) {
                labels[i].setText(read1.nextLine());

                i++;
            } else {
                if (read1.nextLine().equals("End")) {
                    if (read1.hasNextLine()) {
                        labels[i].setText(read1.nextLine());
                        i++;
                    }
                }
            }
        }
    }
    private int countlines()
    {
        File myobj=new File(teachermail+"classwork");
        int count=1;
        try {
            Scanner read=new Scanner(myobj);
            while(read.hasNextLine())
            {
                if(read.nextLine().equals("End"))
                {
                    if(read.hasNext())
                    {
                        read.nextLine();
                        count++;
                    }
                }
            }
            read.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return count;
    }
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(Stream)) {
            this.dispose();
            new Classpage(teachermail,data);
        }
        else if(e.getSource().equals(Classwork))
        {
            this.dispose();
            new classworkpage(teachermail,data);
        }
        else if(e.getSource().equals(People))
        {
            this.dispose();
            new peoplepage(teachermail,data);
        }
        else if(e.getSource().equals(attendence))
        {
            this.dispose();

            new Attendence(teachermail,data);
        }
        else if(e.getSource().equals(back)){
            this.dispose();
            try {
                new allclassesspage(teachermail);
            } catch (FileNotFoundException ex) {
                ex.printStackTrace();
            }
        }
        else if(e.getSource().equals(Create))
        {
            this.dispose();
            new assignclasswork(teachermail,data);
        }
    }
}